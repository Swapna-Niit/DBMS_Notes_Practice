-- create a database
create database demo1;

-- create a table in above database

use demo1;

create table sample(sampleid int,samplename varchar(32));

# drop a database

drop database demo1;